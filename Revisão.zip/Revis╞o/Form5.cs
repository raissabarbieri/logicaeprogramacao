﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevisãoUm
{
    public partial class FrmBiscoitoBolacha : Form
    {
        public FrmBiscoitoBolacha()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bntCalcular_Click(object sender, EventArgs e)
        {
            int unidades = int.Parse(txtUnidades.Text); 
            float calorias = float.Parse(txtCalorias.Text);
            float resultado; 

            resultado = unidades * calorias;
            lblResultado.Text = "O número total de calorias é " + resultado.ToString() + ".";



        }
    }
}
