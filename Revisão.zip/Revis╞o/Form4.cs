﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevisãoUm
{
    public partial class FrmDistancia : Form
    {
        public FrmDistancia()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //declarar variáveis//
            float velocidade = float.Parse(txtVelocidade.Text);
            float tempo = float.Parse(txtTempo.Text);
            float resultado;

            resultado = velocidade * tempo;
            lblResultado.Text = "A distância calculada foi de " + resultado.ToString(); 
                
        }
    }
}
