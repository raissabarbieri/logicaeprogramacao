﻿namespace RevisãoUm
{
    partial class FrmBiscoitoBolacha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntCalcular = new System.Windows.Forms.Button();
            this.lblBiscoitoBolacha = new System.Windows.Forms.Label();
            this.txtUnidades = new System.Windows.Forms.TextBox();
            this.lblUnidades = new System.Windows.Forms.Label();
            this.lblCalorias = new System.Windows.Forms.Label();
            this.txtCalorias = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bntCalcular
            // 
            this.bntCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntCalcular.Location = new System.Drawing.Point(80, 300);
            this.bntCalcular.Name = "bntCalcular";
            this.bntCalcular.Size = new System.Drawing.Size(124, 45);
            this.bntCalcular.TabIndex = 0;
            this.bntCalcular.Text = "CALCULAR";
            this.bntCalcular.UseVisualStyleBackColor = true;
            this.bntCalcular.Click += new System.EventHandler(this.bntCalcular_Click);
            // 
            // lblBiscoitoBolacha
            // 
            this.lblBiscoitoBolacha.AutoSize = true;
            this.lblBiscoitoBolacha.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBiscoitoBolacha.Location = new System.Drawing.Point(63, 73);
            this.lblBiscoitoBolacha.Name = "lblBiscoitoBolacha";
            this.lblBiscoitoBolacha.Size = new System.Drawing.Size(518, 25);
            this.lblBiscoitoBolacha.TabIndex = 1;
            this.lblBiscoitoBolacha.Text = "Calcule a quantidade de calorias no biscoito/bolacha";
            // 
            // txtUnidades
            // 
            this.txtUnidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnidades.Location = new System.Drawing.Point(80, 158);
            this.txtUnidades.Name = "txtUnidades";
            this.txtUnidades.Size = new System.Drawing.Size(124, 29);
            this.txtUnidades.TabIndex = 2;
            // 
            // lblUnidades
            // 
            this.lblUnidades.AutoSize = true;
            this.lblUnidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnidades.Location = new System.Drawing.Point(76, 120);
            this.lblUnidades.Name = "lblUnidades";
            this.lblUnidades.Size = new System.Drawing.Size(90, 24);
            this.lblUnidades.TabIndex = 3;
            this.lblUnidades.Text = "Unidades";
            this.lblUnidades.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblCalorias
            // 
            this.lblCalorias.AutoSize = true;
            this.lblCalorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalorias.Location = new System.Drawing.Point(76, 205);
            this.lblCalorias.Name = "lblCalorias";
            this.lblCalorias.Size = new System.Drawing.Size(77, 24);
            this.lblCalorias.TabIndex = 4;
            this.lblCalorias.Text = "Calorias";
            // 
            // txtCalorias
            // 
            this.txtCalorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalorias.Location = new System.Drawing.Point(80, 244);
            this.txtCalorias.Name = "txtCalorias";
            this.txtCalorias.Size = new System.Drawing.Size(124, 29);
            this.txtCalorias.TabIndex = 5;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(76, 367);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 24);
            this.lblResultado.TabIndex = 6;
            // 
            // FrmBiscoitoBolacha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtCalorias);
            this.Controls.Add(this.lblCalorias);
            this.Controls.Add(this.lblUnidades);
            this.Controls.Add(this.txtUnidades);
            this.Controls.Add(this.lblBiscoitoBolacha);
            this.Controls.Add(this.bntCalcular);
            this.Name = "FrmBiscoitoBolacha";
            this.Text = "Biscoito/Bolacha";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bntCalcular;
        private System.Windows.Forms.Label lblBiscoitoBolacha;
        private System.Windows.Forms.TextBox txtUnidades;
        private System.Windows.Forms.Label lblUnidades;
        private System.Windows.Forms.Label lblCalorias;
        private System.Windows.Forms.TextBox txtCalorias;
        private System.Windows.Forms.Label lblResultado;
    }
}