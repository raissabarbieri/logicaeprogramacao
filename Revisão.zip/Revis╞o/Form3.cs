﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevisãoUm
{
    public partial class FrmMensalidade : Form
    {
        public FrmMensalidade()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Declarar variáveis//
            double mesalidade =  double.Parse(txtValorMensalidade.Text);
            double resultado;

            resultado = mesalidade - (mesalidade * 30 / 100);
            lblResultado.Text = "O valor da mesalidade é de:" + " " + resultado.ToString("C");
        }
    }
}
