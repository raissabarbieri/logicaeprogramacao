﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevisãoUm
{
    public partial class FrmImc : Form
    {
        public FrmImc()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmImc_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Declarar as variáveis
            //string. bool,double (mais de uma operação)
            //MensageBox.Show = Resultado;
            //Retângulo : declarar variáveis 
            //Losângulo : pegar dados na tela 
            //Retãngulo 2 : cálculo
            //Lápis: exibir resultado
            double peso = double.Parse(txtPeso.Text);
            double altura = float.Parse(txtAltura.Text);
            double total;

            total = peso / (altura * altura);
            lblResultado.Text = "O IMC calculado foi de:" + " " + total.ToString();

       

        }
    }
}
