﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revisão_Prova
{
    public partial class FrmRevisão : Form
    {
        public FrmRevisão()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)

        {
            //Declarei as váriavies//
            float valorUm= float.Parse(txtUm.Text);
            float valorDois= float.Parse(txtDois.Text);
            float valorTres = float.Parse(txtTrês.Text);

            //Váriaveis vazias//
            float totalUm;
            float totalDois;
            float totalTres;

            //Conta 10 porcento de um número//
            totalUm = (valorUm * 10/ 100) + valorUm;
            totalDois = (valorDois * 10/ 100) + valorDois;
            totalTres = (valorTres * 10/ 100) + valorTres;

            //Mostrar resultado com $//
            lblResultUm.Text = "Resultado Um = " + totalUm.ToString("C");
            lblResultDois.Text = "Resultado Dois" + totalDois.ToString("C");
            lblResultTrês.Text = "Resultado Três" + totalTres.ToString("C");
            
        }
    }
}
