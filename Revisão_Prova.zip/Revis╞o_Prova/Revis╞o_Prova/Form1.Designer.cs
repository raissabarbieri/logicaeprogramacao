﻿namespace Revisão_Prova
{
    partial class FrmRevisão
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUm = new System.Windows.Forms.Label();
            this.lblDois = new System.Windows.Forms.Label();
            this.lblTrês = new System.Windows.Forms.Label();
            this.txtUm = new System.Windows.Forms.TextBox();
            this.txtDois = new System.Windows.Forms.TextBox();
            this.txtTrês = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblResultUm = new System.Windows.Forms.Label();
            this.lblResultDois = new System.Windows.Forms.Label();
            this.lblResultTrês = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblUm
            // 
            this.lblUm.AutoSize = true;
            this.lblUm.Location = new System.Drawing.Point(121, 89);
            this.lblUm.Name = "lblUm";
            this.lblUm.Size = new System.Drawing.Size(50, 13);
            this.lblUm.TabIndex = 0;
            this.lblUm.Text = "Valor Um";
            // 
            // lblDois
            // 
            this.lblDois.AutoSize = true;
            this.lblDois.Location = new System.Drawing.Point(121, 175);
            this.lblDois.Name = "lblDois";
            this.lblDois.Size = new System.Drawing.Size(55, 13);
            this.lblDois.TabIndex = 1;
            this.lblDois.Text = "Valor Dois";
            // 
            // lblTrês
            // 
            this.lblTrês.AutoSize = true;
            this.lblTrês.Location = new System.Drawing.Point(121, 256);
            this.lblTrês.Name = "lblTrês";
            this.lblTrês.Size = new System.Drawing.Size(55, 13);
            this.lblTrês.TabIndex = 2;
            this.lblTrês.Text = "Valor Três";
            // 
            // txtUm
            // 
            this.txtUm.Location = new System.Drawing.Point(124, 127);
            this.txtUm.Name = "txtUm";
            this.txtUm.Size = new System.Drawing.Size(100, 20);
            this.txtUm.TabIndex = 3;
            // 
            // txtDois
            // 
            this.txtDois.Location = new System.Drawing.Point(124, 209);
            this.txtDois.Name = "txtDois";
            this.txtDois.Size = new System.Drawing.Size(100, 20);
            this.txtDois.TabIndex = 4;
            // 
            // txtTrês
            // 
            this.txtTrês.Location = new System.Drawing.Point(124, 288);
            this.txtTrês.Name = "txtTrês";
            this.txtTrês.Size = new System.Drawing.Size(100, 20);
            this.txtTrês.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(124, 338);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 42);
            this.button1.TabIndex = 6;
            this.button1.Text = "CALCULAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblResultUm
            // 
            this.lblResultUm.AutoSize = true;
            this.lblResultUm.Location = new System.Drawing.Point(124, 417);
            this.lblResultUm.Name = "lblResultUm";
            this.lblResultUm.Size = new System.Drawing.Size(80, 13);
            this.lblResultUm.TabIndex = 7;
            this.lblResultUm.Text = "Resultado Um :";
            // 
            // lblResultDois
            // 
            this.lblResultDois.AutoSize = true;
            this.lblResultDois.Location = new System.Drawing.Point(124, 464);
            this.lblResultDois.Name = "lblResultDois";
            this.lblResultDois.Size = new System.Drawing.Size(82, 13);
            this.lblResultDois.TabIndex = 8;
            this.lblResultDois.Text = "Resultado Dois:";
            // 
            // lblResultTrês
            // 
            this.lblResultTrês.AutoSize = true;
            this.lblResultTrês.Location = new System.Drawing.Point(124, 507);
            this.lblResultTrês.Name = "lblResultTrês";
            this.lblResultTrês.Size = new System.Drawing.Size(82, 13);
            this.lblResultTrês.TabIndex = 9;
            this.lblResultTrês.Text = "Resultado Três:";
            // 
            // FrmRevisão
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 588);
            this.Controls.Add(this.lblResultTrês);
            this.Controls.Add(this.lblResultDois);
            this.Controls.Add(this.lblResultUm);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtTrês);
            this.Controls.Add(this.txtDois);
            this.Controls.Add(this.txtUm);
            this.Controls.Add(this.lblTrês);
            this.Controls.Add(this.lblDois);
            this.Controls.Add(this.lblUm);
            this.Name = "FrmRevisão";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUm;
        private System.Windows.Forms.Label lblDois;
        private System.Windows.Forms.Label lblTrês;
        private System.Windows.Forms.TextBox txtUm;
        private System.Windows.Forms.TextBox txtDois;
        private System.Windows.Forms.TextBox txtTrês;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblResultUm;
        private System.Windows.Forms.Label lblResultDois;
        private System.Windows.Forms.Label lblResultTrês;
    }
}

