﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem
{
    public partial class FrmMensagem : Form
    {
        public FrmMensagem()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriuuuuuuu");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Textoooooooooo");
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Outro textooooo");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Outro botãooooooo");
        }

        private void boo_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Outro do outro do outro texto");
        }

        private void TxtTex_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Outro do outro texto");
        }

        private void BtnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botãooooooo");
        }

        private void LblInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Escrevaaa");
        }

        private void LblDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Escrevaaa novamente");
        }

        private void LblTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Escrevaaa novamente novamente");
        }

        private void LblBooleando_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Escrevaaa novamente novamente novamente");
        }
    }
}
