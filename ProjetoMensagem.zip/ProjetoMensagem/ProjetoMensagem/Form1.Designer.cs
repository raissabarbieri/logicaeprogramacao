﻿namespace ProjetoMensagem
{
    partial class FrmMensagem
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtInteiro = new System.Windows.Forms.Label();
            this.TxtDecimal = new System.Windows.Forms.Label();
            this.TxtTex = new System.Windows.Forms.Label();
            this.TxtBooleando = new System.Windows.Forms.Label();
            this.LblInteiro = new System.Windows.Forms.TextBox();
            this.LblDecimal = new System.Windows.Forms.TextBox();
            this.LblTexto = new System.Windows.Forms.TextBox();
            this.BtnMostrar = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.LblBooleando = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtInteiro
            // 
            this.TxtInteiro.AutoSize = true;
            this.TxtInteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtInteiro.Location = new System.Drawing.Point(41, 24);
            this.TxtInteiro.Name = "TxtInteiro";
            this.TxtInteiro.Size = new System.Drawing.Size(72, 26);
            this.TxtInteiro.TabIndex = 0;
            this.TxtInteiro.Text = "Inteiro";
            this.TxtInteiro.Click += new System.EventHandler(this.label1_Click);
            // 
            // TxtDecimal
            // 
            this.TxtDecimal.AutoSize = true;
            this.TxtDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDecimal.Location = new System.Drawing.Point(41, 99);
            this.TxtDecimal.Name = "TxtDecimal";
            this.TxtDecimal.Size = new System.Drawing.Size(92, 26);
            this.TxtDecimal.TabIndex = 1;
            this.TxtDecimal.Text = "Decimal";
            this.TxtDecimal.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // TxtTex
            // 
            this.TxtTex.AutoSize = true;
            this.TxtTex.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTex.Location = new System.Drawing.Point(41, 168);
            this.TxtTex.Name = "TxtTex";
            this.TxtTex.Size = new System.Drawing.Size(65, 26);
            this.TxtTex.TabIndex = 2;
            this.TxtTex.Text = "Texto";
            this.TxtTex.Click += new System.EventHandler(this.TxtTex_Click);
            // 
            // TxtBooleando
            // 
            this.TxtBooleando.AutoSize = true;
            this.TxtBooleando.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBooleando.Location = new System.Drawing.Point(41, 240);
            this.TxtBooleando.Name = "TxtBooleando";
            this.TxtBooleando.Size = new System.Drawing.Size(116, 26);
            this.TxtBooleando.TabIndex = 3;
            this.TxtBooleando.Text = "Booleando";
            this.TxtBooleando.Click += new System.EventHandler(this.boo_Click);
            // 
            // LblInteiro
            // 
            this.LblInteiro.Location = new System.Drawing.Point(46, 53);
            this.LblInteiro.Name = "LblInteiro";
            this.LblInteiro.Size = new System.Drawing.Size(183, 20);
            this.LblInteiro.TabIndex = 4;
            this.LblInteiro.TextChanged += new System.EventHandler(this.LblInteiro_TextChanged);
            // 
            // LblDecimal
            // 
            this.LblDecimal.Location = new System.Drawing.Point(46, 128);
            this.LblDecimal.Name = "LblDecimal";
            this.LblDecimal.Size = new System.Drawing.Size(183, 20);
            this.LblDecimal.TabIndex = 5;
            this.LblDecimal.TextChanged += new System.EventHandler(this.LblDecimal_TextChanged);
            // 
            // LblTexto
            // 
            this.LblTexto.Location = new System.Drawing.Point(46, 197);
            this.LblTexto.Name = "LblTexto";
            this.LblTexto.Size = new System.Drawing.Size(183, 20);
            this.LblTexto.TabIndex = 6;
            this.LblTexto.TextChanged += new System.EventHandler(this.LblTexto_TextChanged);
            // 
            // BtnMostrar
            // 
            this.BtnMostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMostrar.Location = new System.Drawing.Point(27, 320);
            this.BtnMostrar.Name = "BtnMostrar";
            this.BtnMostrar.Size = new System.Drawing.Size(97, 35);
            this.BtnMostrar.TabIndex = 7;
            this.BtnMostrar.Text = "Mostrar";
            this.BtnMostrar.UseVisualStyleBackColor = true;
            this.BtnMostrar.Click += new System.EventHandler(this.BtnMostrar_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimpar.Location = new System.Drawing.Point(151, 320);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(97, 35);
            this.BtnLimpar.TabIndex = 8;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.button2_Click);
            // 
            // LblBooleando
            // 
            this.LblBooleando.Location = new System.Drawing.Point(46, 269);
            this.LblBooleando.Name = "LblBooleando";
            this.LblBooleando.Size = new System.Drawing.Size(183, 20);
            this.LblBooleando.TabIndex = 9;
            this.LblBooleando.TextChanged += new System.EventHandler(this.LblBooleando_TextChanged);
            // 
            // FrmMensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetoMensagem.Properties.Resources.patati_patata_001c676d;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(269, 378);
            this.Controls.Add(this.LblBooleando);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnMostrar);
            this.Controls.Add(this.LblTexto);
            this.Controls.Add(this.LblDecimal);
            this.Controls.Add(this.LblInteiro);
            this.Controls.Add(this.TxtBooleando);
            this.Controls.Add(this.TxtTex);
            this.Controls.Add(this.TxtDecimal);
            this.Controls.Add(this.TxtInteiro);
            this.MaximizeBox = false;
            this.Name = "FrmMensagem";
            this.Text = "Envio de Mensagem";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TxtInteiro;
        private System.Windows.Forms.Label TxtDecimal;
        private System.Windows.Forms.Label TxtTex;
        private System.Windows.Forms.Label TxtBooleando;
        private System.Windows.Forms.TextBox LblInteiro;
        private System.Windows.Forms.TextBox LblDecimal;
        private System.Windows.Forms.TextBox LblTexto;
        private System.Windows.Forms.Button BtnMostrar;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.TextBox LblBooleando;
    }
}

